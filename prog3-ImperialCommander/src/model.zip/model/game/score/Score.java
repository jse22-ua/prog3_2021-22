package model.game.score;

public abstract class Score<T> implements Comparable<Score<T>> {

}
