package model.game.score;

public class WinsScore {

}
