package model.game.score;

public class DestroyedFightersScore {

}
