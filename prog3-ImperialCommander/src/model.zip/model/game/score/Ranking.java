package model.game.score;

public class Ranking {

}
