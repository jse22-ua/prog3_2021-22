package model;

public enum Side {
	IMPERIAL,REBEL
}
